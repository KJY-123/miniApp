Page({
  // 页面的初始数据
  data: {},

  // 保存收货地址
  saveAddrssForm(event) {},

  // 省市区选择
  onAddressChange(event) {}
})
