// pages/order/list/index.js
Page({
  // 页面的初始数据
  data: {
    orderList: [1, 2, 3]
  }
})
