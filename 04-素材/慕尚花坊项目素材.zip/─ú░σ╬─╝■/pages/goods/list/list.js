// pages/goods/list/index.js

Page({
  /**
   * 页面的初始数据
   */
  data: {
    goodsList: [], // 商品列表数据
    isFinish: false // 判断数据是否加载完毕
  }

})
